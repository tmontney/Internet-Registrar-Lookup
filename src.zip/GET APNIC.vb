﻿Imports System.Reflection

Namespace Internet_Registry.GET
    Public Class Get_APNIC
        Public Property inetnum As String
        Public Property netname As String
        Public Property descr As String()
        Public Property country As String
        Public Property admin_c As String()
        Public Property tech_c As String()
        Public Property remarks As String()
        Public Property mnt_by As String
        Public Property mnt_irt As String
        Public Property status As String
        Public Property changed As String

        Public Property irt As String
        Public Property address As String()
        Public Property e_mail As String
        Public Property abuse_mailbox As String
        Public Property orgadmin_c As String()
        Public Property orgtech_c As String()
        Public Property orgmnt_by As String
        Public Property orgchanged As String()


        Public Sub Retrieve(ByVal RiR_As_Collection As Collection, ByRef Get_Results_Obj As Get_APNIC)
            Dim t As Get_APNIC = Get_Results_Obj
            Dim propInfo() As PropertyInfo = Me.GetType().GetProperties()
            Dim prp As String = String.Empty
            Dim foundMatch As Boolean = False
            Dim breakPassed As Boolean = False
            For Each line In RiR_As_Collection
                For i As Integer = 0 To propInfo.Length - 1
                    prp = propInfo(i).Name
                    prp = prp.Replace("_", "-")
                    If breakPassed = True Then
                        prp = prp.Replace("org", "")
                    End If
                    If breakPassed = False Then
                        If line.Contains("descr") And descr Is Nothing Then
                            descr = Get_MultiValue(RiR_As_Collection, "inetnum", "source", "descr")
                            foundMatch = True
                        ElseIf line.Contains("tech-c") And tech_c Is Nothing Then
                            tech_c = Get_MultiValue(RiR_As_Collection, "inetnum", "source", "tech-c")
                            foundMatch = True
                        ElseIf line.Contains("remarks") And remarks Is Nothing Then
                            remarks = Get_MultiValue(RiR_As_Collection, "inetnum", "source", "remarks")
                            foundMatch = True
                        ElseIf line.Contains("admin-c") And admin_c Is Nothing Then
                            admin_c = Get_MultiValue(RiR_As_Collection, "inetnum", "source", "admin-c")
                            foundMatch = True
                        ElseIf line.Contains(prp) And propInfo(i).PropertyType IsNot GetType(System.String()) Then
                            Dim curValue As String = propInfo(i).GetValue(t, Nothing)
                            If curValue = String.Empty Or curValue Is Nothing Then
                                propInfo(i).SetValue(t, Trim_Value(line, prp), Nothing)
                                foundMatch = True
                            End If
                        End If
                    Else
                        If line.Contains("address") And address Is Nothing Then
                            address = Get_MultiValue(RiR_As_Collection, "irt", "mailbox", "address")
                            foundMatch = True
                        ElseIf line.Contains("admin-c") And orgadmin_c Is Nothing Then
                            orgadmin_c = Get_MultiValue(RiR_As_Collection, "irt", "source", "admin-c")
                            foundMatch = True
                        ElseIf line.Contains("tech-c") And orgtech_c Is Nothing Then
                            orgtech_c = Get_MultiValue(RiR_As_Collection, "irt", "source", "tech-c")
                            foundMatch = True
                        ElseIf line.Contains("mnt-by") And orgmnt_by Is Nothing Then
                            orgmnt_by = Trim_Value(line, prp)
                        ElseIf line.Contains("changed") And orgchanged Is Nothing Then
                            orgtech_c = Get_MultiValue(RiR_As_Collection, "irt", "source", "changed")
                        ElseIf line.Contains(prp) And propInfo(i).PropertyType IsNot GetType(System.String()) Then
                            Dim curValue As String = propInfo(i).GetValue(t, Nothing)
                            If curValue = String.Empty Or curValue Is Nothing Then
                                propInfo(i).SetValue(t, Trim_Value(line, prp), Nothing)
                                foundMatch = True
                            End If
                        End If
                    End If
                    If line.Contains("irt") And Not line.Contains("mnt-irt") Then
                        breakPassed = True
                    End If
                    If foundMatch = True Then
                        foundMatch = False
                        Exit For
                    End If
                Next
            Next
        End Sub

        Private Function Get_MultiValue(ByRef RiR_As_Collection As Collection, ByVal startAtHeader As String, ByVal stopatheader As String, ByVal header As String) As String()
            Dim startIndex As Integer = 0
            Dim endIndex As Integer = 0
            Dim j As Integer = 0
            Dim k As Integer = 0
            Dim l As Integer = 0
            Dim innerArray(10) As String
            For Each line In RiR_As_Collection
                If line.Contains(startAtHeader) Then
                    Exit For
                End If
                l += 1
            Next
            startIndex = l
            For Each line In RiR_As_Collection
                If line.Contains(stopatheader) Then
                    Exit For
                End If
                j += 1
            Next
            endIndex = j
            For i As Integer = startIndex To endIndex
                If RiR_As_Collection(i).ToString.Contains(header) Then
                    innerArray(k) = Trim_Value(RiR_As_Collection(i), header)
                    k += 1
                End If
            Next
            Return innerArray
        End Function

        Private Function Trim_Value(ByVal value As String, ByVal propName As String) As String
            value = value.Replace(propName & ":", "")
            value = value.Replace(Chr(34), "")
            If value.Contains("inetnum") Then
                value = value.Substring(value.IndexOf(">:") + 2)
                value = value.Replace(" ", "")
            End If
            Return value
        End Function
    End Class
End Namespace