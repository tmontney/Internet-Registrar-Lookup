﻿Imports System.Reflection

Namespace Internet_Registry.GET
    Public Class Get_APNIC
        Public Property inetnum As String
        Public Property netname As String
        Public Property descr As String
        Public Property country As String
        Public Property remarks As String

        Public Sub Retrieve(ByVal RiR_As_Collection As Collection, ByRef Get_Results_Obj As Get_APNIC)
            Dim t As Get_APNIC = Get_Results_Obj
            Dim propInfo() As PropertyInfo = Me.GetType().GetProperties()
            For i As Integer = 0 To propInfo.Length - 1
                propInfo(i).SetValue(t, Get_Value(propInfo(i).Name, RiR_As_Collection), Nothing)
            Next
        End Sub

        Private Function Get_Value(ByVal Property_Name As String, ByVal RiR_As_Collection As Collection) As String
            Dim returnValue As String = String.Empty
            Dim keepReading As Boolean = False
            Dim descrCombined As String = String.Empty
            For Each line In RiR_As_Collection
                If line.Contains("descr") And keepReading = False And descr = String.Empty Then
                    keepReading = True
                    descrCombined = descrCombined & line & vbNewLine
                ElseIf keepReading = True Then
                    If line.Contains("descr") = False Then
                        keepReading = False
                        Exit For
                    Else
                        descrCombined = descrCombined & line & vbNewLine
                    End If
                ElseIf line.Contains(Property_Name) Then
                    Return Trim_Value(line, Property_Name)
                End If
            Next
            If descrCombined <> String.Empty Then
                Return Trim_Value(descrCombined, Property_Name)
            Else
                Return String.Empty
            End If
        End Function
        Private Function Trim_Value(ByVal value As String, ByVal propName As String) As String
            value = value.Replace(propName & ":", "")
            value = value.Replace(Chr(34), "")
            If value.Contains("inetnum") Then
                value = value.Substring(value.IndexOf(">:") + 2)
                value = value.Replace(" ", "")
            End If
            Return value
        End Function
    End Class
End Namespace