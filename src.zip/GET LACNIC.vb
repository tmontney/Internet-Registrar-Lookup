﻿Imports System.Reflection
Namespace Internet_Registry.GET
    Public Class GET_LACNIC
        Public Property Handle As String
        Public Property Name As String
        Public Property Status As String
        Public Property Parent As String
        Public Property Net_Range As String
        Public Property Net_Version As String
        Public Property Country As String
        Public Property LAST_CHANGED As String

        Public Sub Retrieve(ByVal RiR_As_Collection As Collection, ByRef Get_Results_Obj As GET_LACNIC)
            Dim t As GET_LACNIC = Get_Results_Obj
            Dim propInfo() As PropertyInfo = Me.GetType().GetProperties()
            Dim goToValue As Boolean = False
            For i As Integer = 0 To propInfo.Length - 1
                Dim curPropName As String = propInfo(i).Name
                curPropName = propInfo(i).Name
                If curPropName.Contains("_") And i <> 7 Then
                    curPropName = curPropName.Replace("_", " ")
                End If
                For Each element In RiR_As_Collection
                    If goToValue = False And element <> String.Empty And element.Contains(curPropName) Then
                        goToValue = True
                    ElseIf goToValue = True And element <> String.Empty Then
                        goToValue = False
                        element = Remove_Tags(element)
                        propInfo(i).SetValue(t, element, Nothing)
                    End If
                Next
            Next
        End Sub

        Private Function Remove_Tags(ByVal value As String) As String
            Dim count As Integer = 0
            For Each character As Char In value
                If character = "<"c Then
                    count += 1
                End If
            Next
            For i As Integer = 0 To count - 1
                Dim startIndex As Integer = value.IndexOf("<"c)
                Dim endIndex As Integer = value.IndexOf(">"c) + 1
                value = value.Remove(startIndex, endIndex - startIndex)
            Next
            Return value
        End Function
    End Class
End Namespace
