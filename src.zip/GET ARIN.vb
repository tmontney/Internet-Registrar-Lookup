﻿Imports System.Reflection
Imports System.IO

Namespace Internet_Registry.GET
    ''' <summary>
    ''' Retrieves WHOIS query and organizes the data accordingly.
    ''' </summary>
    Public Class GET_ARIN
        Public Property NetRange As String = String.Empty
        Public Property CIDR As String = String.Empty
        Public Property NetName As String = String.Empty
        Public Property NetHandle As String = String.Empty
        Public Property Parent As String = String.Empty
        Public Property NetType As String = String.Empty
        Public Property OriginAS As String = String.Empty
        Public Property Organization As String = String.Empty
        Public Property RegDate As String = String.Empty
        Public Property Updated As String = String.Empty
        Public Property Comment As String = String.Empty
        Public Property Ref As String = String.Empty

        Public Property OrgName As String = String.Empty
        Public Property OrgId As String = String.Empty
        Public Property Address As String = String.Empty
        Public Property City As String = String.Empty
        Public Property StateProv As String = String.Empty
        Public Property PostalCode As String = String.Empty
        Public Property Country As String = String.Empty
        Public Property orgRegDate As String = String.Empty
        Public Property orgUpdated As String = String.Empty
        Public Property orgComment As String = String.Empty
        Public Property orgRef As String = String.Empty
        '''<summary>Example: https://whois.arin.net/rest/net/NET-209-41-160-0-1.txt </summary>
        ''' <param name="RiR_As_Collection">This is the entire ARIN WHOIS query in text only.</param>
        ''' <param name="Get_Results_Obj">"Pass a newly created instance of this class here. The properties will populate once this routine is run.</param>
        Public Sub Retrieve(ByVal RiR_As_Collection As Collection, ByRef Get_Results_Obj As GET_ARIN)
            Dim t As GET_ARIN = Get_Results_Obj
            Dim propInfo() As PropertyInfo = Me.GetType().GetProperties()
            Dim breakPassed As Boolean = False
            For Each line As String In RiR_As_Collection
                If line.Contains("#") = False And line <> String.Empty Then
                    If line.Contains("BREAK") Then
                        breakPassed = True
                    End If
                    For i As Integer = 0 To propInfo.Length - 1
                        Dim propName As String = propInfo(i).Name
                        If line.Contains("RegDate") And breakPassed = True Then
                            orgRegDate = Trim_Value(line, "RegDate")
                        ElseIf line.Contains("Updated") And breakPassed = True Then
                            orgUpdated = Trim_Value(line, "Updated")
                        ElseIf line.Contains("Comment") And breakPassed = True Then
                            orgComment = Trim_Value(line, "Comment")
                        ElseIf line.Contains("Ref") And breakPassed = True Then
                            orgRef = Trim_Value(line, "Ref")
                        ElseIf line.Contains(propName) Then
                            Dim innerProp As PropertyInfo = t.GetType().GetProperty(propInfo(i).Name)
                            innerProp.SetValue(t, Trim_Value(line, innerProp.Name), Nothing)
                            Exit For
                        End If
                    Next
                End If
            Next
        End Sub

        'Removes unneeded characters before it is stored as a property.
        'Line is a line from the WHOIS query. It is the data to be trimmed.
        'Header is the header for the data. It is the same name as the property so it can be easily removed from the query.
        Private Function Trim_Value(ByVal line As String, ByVal header As String) As String
            line = line.Replace(":"c, "")
            line = line.Replace(header, "")
            If header <> "Comment" Then
                line = line.Replace(" ", "")
            End If
            Return line
        End Function
    End Class
End Namespace
