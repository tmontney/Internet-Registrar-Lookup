﻿Imports System.Net
Imports System.Xml
Imports System.IO

Namespace Internet_Registry.GET
    Public Class GET_RAW
        Private registrarname As RIR_Type
        Public Property IP_Address As IPAddress
        Public Property Organization As String
        Public Property Current_Net_Range As String
        Public ReadOnly Property Registrar_Name As RIR_Type
            Get
                Return registrarname
            End Get
        End Property

#Region "RIR Helpers"

        Enum RIR_Type As Integer
            ARIN = 0
            RIPE = 1
            LACNIC = 2
            APNIC = 3
            AFRINIC = 4
        End Enum

        Public Function Check_If_ARIN(ByVal Download_String As String()) As RIR_Type
            For Each element In Download_String
                If element.Contains("RIPE") Then
                    registrarname = RIR_Type.RIPE
                    Return Registrar_Name
                ElseIf element.Contains("LACNIC") Then
                    registrarname = RIR_Type.LACNIC
                    Return Registrar_Name
                ElseIf element.Contains("APNIC") Then
                    registrarname = RIR_Type.APNIC
                    Return Registrar_Name
                ElseIf element.Contains("AFRINIC") Then
                    registrarname = RIR_Type.AFRINIC
                    Return Registrar_Name
                End If
            Next
            registrarname = RIR_Type.ARIN
            Return Registrar_Name
        End Function

        Private Function Is_This_An_IP(ByVal line As String) As Boolean
            Dim count As Integer = 0
            For Each character As Char In line
                If character = "." Then
                    count += 1
                    If count >= 3 Then
                        Return True
                    End If
                End If
            Next
            Return False
        End Function

#End Region

#Region "ARIN"

        Public ReadOnly Property ARIN_Download_String As String()
            Get
                Dim inner(1) As String
                inner(0) = "http://whois.arin.net/rest/ip/" & IP_Address.ToString & ".txt"
                inner(1) = "https://whois.arin.net/rest/org/" & Organization & ".txt"
                Return inner
            End Get
        End Property

        Public Function ARIN() As Collection
            Dim arinWC As New WebClient
            arinWC.Headers.Add("user-agent", "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.101 Safari/537.36")
            Dim IP_Address_STR As String = arinWC.DownloadString(ARIN_Download_String(0))
            arinWC.Dispose()
            Dim ipLines As String() = IP_Address_STR.Split(Chr(10))
            Dim combinedLines As New Collection
            Dim Check_If_ARIN_Result As RIR_Type = Check_If_ARIN(ipLines)
            If Check_If_ARIN_Result = RIR_Type.ARIN Then
                For Each element In ipLines
                    If element.Contains("NetRange") Then
                        Current_Net_Range = element
                    ElseIf element.Contains("Organization") Then
                        Dim sIndex As Integer = element.IndexOf("("c) + 1
                        Organization = element.Substring(sIndex, (element.Length - sIndex) - 1)
                    End If
                    combinedLines.Add(element)
                Next
                combinedLines.Add("BREAK")
                Dim IP_Address_ORG_STR As String = arinWC.DownloadString(ARIN_Download_String(1))
                Dim orgIPLines As String() = IP_Address_ORG_STR.Split(Chr(10))
                For Each element In orgIPLines
                    combinedLines.Add(element)
                Next
                Return combinedLines
            Else

                combinedLines.Add(Check_If_ARIN_Result.ToString & " manages this address.")
                Return combinedLines
            End If
        End Function
#End Region

#Region "RIPE"

        Public ReadOnly Property RIPE_Download_String As String
            Get
                Return "http://rest.db.ripe.net/search?source=RIPE&query-string=" & IP_Address.ToString
            End Get
        End Property

        Public Function RIPE() As Collection
            Dim ripeWC As New WebClient
            Dim collectionLines As New Collection
            ripeWC.Headers.Add("user-agent", "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.101 Safari/537.36")
            Dim IP_Address_STR As String = ripeWC.DownloadString(RIPE_Download_String)
            ripeWC.Dispose()
            Dim ipLines As String() = IP_Address_STR.Split(Chr(10))
            For Each element In ipLines
                If element.Contains("attribute name=" & Chr(34) & "inetnum" & Chr(34)) Then
                    Current_Net_Range = element
                    Current_Net_Range = Current_Net_Range.Replace("<attribute name=" & Chr(34) & "inetnum" & Chr(34) & " value=", "")
                    Current_Net_Range = Current_Net_Range.Replace("/>", "")
                    Current_Net_Range = Current_Net_Range.Replace(" ", "")
                    Current_Net_Range = Current_Net_Range.Replace(Chr(34), "")
                    Exit For
                End If
            Next
            For Each element In ipLines
                collectionLines.Add(element)
            Next
            Return collectionLines
        End Function

#End Region

#Region "LACNIC"

        Public ReadOnly Property LACNIC_Download_String As String
            Get
                Return "http://rdap.lacnic.net/rdap-web/ip?key=" & IP_Address.ToString
            End Get
        End Property

        Public Function LACNIC() As Collection
            Dim lacnicWC As New WebClient
            Dim collectionLines As New Collection
            lacnicWC.Headers.Add("user-agent", "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.101 Safari/537.36")
            Dim IP_Address_STR As String = lacnicWC.DownloadString(LACNIC_Download_String)
            lacnicWC.Dispose()
            Dim ipLines As String() = IP_Address_STR.Split(Chr(10))
            For Each element In ipLines
                If element.Contains("<span>") And element.Contains("-") And element.Count > 3 Then
                    Dim count As Integer = 0
                    For Each character As Char In element
                        If character = "." Then
                            count += 1
                            If count > 3 Then
                                Exit For
                            End If
                        End If
                    Next
                    If count > 3 Then
                        Current_Net_Range = element
                        Current_Net_Range = Current_Net_Range.Replace("<td>", "")
                        Current_Net_Range = Current_Net_Range.Replace("</td>", "")
                        Current_Net_Range = Current_Net_Range.Replace("<span>", "")
                        Current_Net_Range = Current_Net_Range.Replace("</span>", "")
                        Current_Net_Range = Current_Net_Range.Replace(" ", "")
                        Exit For
                    End If
                End If
            Next
            For Each element In ipLines
                collectionLines.Add(element)
            Next
            Return collectionLines
        End Function
#End Region

#Region "APNIC"

        Public ReadOnly Property APNIC_Download_String As String
            Get
                Return "http://wq.apnic.net/apnic-bin/whois.pl?do_search=Search&searchtext=" & IP_Address.ToString
            End Get
        End Property

        Public Function APNIC() As Collection
            Dim apnicWC As New WebClient
            Dim collectionLines As New Collection
            apnicWC.Headers.Add("user-agent", "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.101 Safari/537.36")
            Dim IP_Address_STR As String = apnicWC.DownloadString(APNIC_Download_String)
            'Dim htmlDoc As HTMLDocument = APNIC_HTMLDocument(IP_Address_STR)
            apnicWC.Dispose()
            Dim ipLines As String() = IP_Address_STR.Split(Chr(10))
            Dim count As Integer = 0
            Dim foundStartPoint As Boolean = False
            Dim strCombine As String = String.Empty
            For Each element In ipLines
                If element.Contains("inetnum") Then
                    element = element.Substring(element.IndexOf(">:") + 2)
                    element = element.Replace(" ", "")
                    Current_Net_Range = element
                    Exit For
                End If
            Next
            For Each element In ipLines
                collectionLines.Add(element)
            Next
            Return collectionLines
        End Function

#End Region

#Region "AFRINIC"

        'Public ReadOnly Property AFRINIC_Download_String As String
        '    Get
        '        Return "https://www.afrinic.net/services/whois-query"
        '    End Get
        'End Property

        'Public Function AFRINIC(Optional ByVal Post_Navigate_Results As String = "") As String()
        '    AFRINIC_Navigate()
        '    While Post_Navigate_Results = ""
        '    End While
        '    Dim ipLines As String() = Post_Navigate_Results.Split()
        '    For Each element As String In ipLines

        '    Next
        '    Return ipLines
        'End Function

        'Private Sub AFRINIC_Navigate()
        '    afrinicWC = New Awesomium.Windows.Forms.WebControl
        '    afrinicWC.Source = New Uri(AFRINIC_Download_String)
        '    main.afrinic_Timer.Start()
        'End Sub

        'Public Function AFRINIC_Post_Navigate() As String
        '    If afrinicWC.IsDocumentReady = True And afrinicWC.IsLoading = False Then
        '        Dim vsWC As New WebClient
        '        Return vsWC.DownloadString(afrinicWC.Source)
        '    Else
        '        Return "-1"
        '    End If
        'End Function

#End Region

    End Class
End Namespace
