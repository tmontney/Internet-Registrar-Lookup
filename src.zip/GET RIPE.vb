﻿Imports System.Reflection
Namespace Internet_Registry.GET
    Public Class Get_RIPE
        Public Property inetnum As String
        Public Property netname As String
        Public Property descr As String
        Public Property country As String
        Public Property created As String
        Public Property last_modified As String


        Public Sub Retrieve(ByVal RiR_As_Collection As Collection, ByRef Get_Results_Obj As Get_RIPE)
            Dim t As Get_RIPE = Get_Results_Obj
            Dim propInfo() As PropertyInfo = Me.GetType().GetProperties()
            Dim i As Integer = 0
            For Each line As String In RiR_As_Collection
                Dim propName As String = propInfo(i).Name
                If propName = "last_modified" Then
                    propName = propName.Replace("_", "-")
                End If
                If line.Contains("attribute name=" & Chr(34) & propName) Then
                    Dim startIndex As Integer = line.IndexOf("value=" & Chr(34)) + 7
                    Dim endIndex As Integer = line.LastIndexOf(Chr(34))
                    Dim prp As String = line.Substring(startIndex, endIndex - startIndex)
                    prp = prp.Replace(" ", "")
                    propInfo(i).SetValue(Get_Results_Obj, prp, Nothing)
                    i += 1
                    If i = propInfo.Length Then
                        Exit For
                    End If
                End If
            Next
        End Sub
    End Class
End Namespace
