﻿Imports System.Reflection
Namespace Internet_Registry.GET
    Public Class Get_RIPE
        Public Property date_occurred As String = String.Empty
        Public Property address_scanned As String = String.Empty

        Public Property inetnum As String
        Public Property netname As String
        Public Property descr As String()
        Public Property country As String
        Public Property admin_c As String
        Public Property tech_c As String
        Public Property mnt_by As String
        Public Property created As String
        Public Property last_modified As String

        Public Property person As String
        Public Property address As String()
        Public Property phone As String
        Public Property nic_hdl As String
        Public Property orgmnt_by As String
        Public Property orgcreated As String
        Public Property orglast_modified As String


        Public Sub Retrieve(ByVal RiR_As_Collection As Collection, ByRef Get_Results_Obj As Get_RIPE)
            Dim t As Get_RIPE = Get_Results_Obj
            Dim propInfo() As PropertyInfo = Me.GetType().GetProperties()
            Dim breakPassed As Boolean = False
            Dim i As Integer = 0
            Dim j As Integer = 1
            For Each line As String In RiR_As_Collection
                Dim propName As String = propInfo(i).Name
                If propName <> "date_occurred" And propName <> "address_scanned" Then
                    If propName.Contains("_") Then
                        propName = propName.Replace("_", "-")
                    End If
                    If breakPassed = True Then
                        propName = propName.Replace("org", "")
                    End If
                    If line.Contains("attribute name=" & Chr(34) & propName) Then
                        If propName = "descr" Then
                            descr = Get_Descriptions(RiR_As_Collection)
                        ElseIf propName = "address" Then
                            address = Get_Organizational_Info(RiR_As_Collection, "address")
                        Else
                            Dim startIndex As Integer = line.IndexOf("value=" & Chr(34)) + 7
                            Dim endIndex As Integer = line.IndexOf(Chr(34), startIndex)
                            Dim prp As String = line.Substring(startIndex, endIndex - startIndex)
                            prp = prp.Replace(" ", "")
                            If breakPassed = False Then
                                If propName <> "descr" And propName <> "address" Then
                                    propInfo(i).SetValue(Get_Results_Obj, prp, Nothing)
                                End If
                                If propName = "nic-hdl" Then
                                    breakPassed = True
                                End If
                            Else
                                If propName = "mnt-by" Then
                                    orgmnt_by = prp
                                ElseIf propName = "created" Then
                                    orgcreated = prp
                                ElseIf propName = "last-modified" Then
                                    orglast_modified = prp
                                End If
                            End If
                        End If
                        i += 1
                        If i = propInfo.Length Then
                            Exit For
                        End If
                    End If
                    RiR_As_Collection.Remove(1)
                Else
                    i += 1
                End If
            Next
        End Sub

        Public Function Get_Descriptions(ByVal RiR_As_Collection As Collection) As String()
            Dim endIndex As Integer = 0
            Dim indexArray(5) As String
            Dim i As Integer = 1
            For Each line As String In RiR_As_Collection
                If line.Contains("attribute name=" & Chr(34) & "source") And line.Contains("value=") Then
                    endIndex = i
                    Exit For
                End If
                i += 1
            Next
            Dim h As Integer = 0
            For j As Integer = 1 To endIndex
                With RiR_As_Collection(j)
                    If RiR_As_Collection(j).ToString.Contains("descr") Then
                        Dim sIndex As Integer = .ToString.IndexOf("value=" & Chr(34)) + 7
                        Dim eIndex As Integer = .ToString.LastIndexOf(Chr(34))
                        Dim prp As String = .ToString.Substring(sIndex, eIndex - sIndex)
                        'prp = prp.Replace(" ", "")
                        indexArray(h) = prp
                        h += 1
                    End If
                End With
            Next
            Return indexArray
        End Function

        Public Function Get_Organizational_Info(ByVal RiR_As_Collection As Collection, ByVal header As String) As String()
            Dim endIndex As Integer = 0
            Dim indexArray(10) As String
            Dim i As Integer = 0
            For Each line As String In RiR_As_Collection
                If line.Contains("attribute name=" & Chr(34) & "source" & Chr(34) & " value=") Then
                    endIndex = i
                    Exit For
                End If
                i += 1
            Next
            Dim h As Integer = 0
            For j As Integer = 1 To endIndex - 1
                With RiR_As_Collection(j)
                    If RiR_As_Collection(j).ToString.Contains(header) Then
                        Dim sIndex As Integer = .ToString.IndexOf("value=" & Chr(34)) + 7
                        Dim eIndex As Integer = .ToString.LastIndexOf(Chr(34))
                        Dim prp As String = .ToString.Substring(sIndex, eIndex - sIndex)
                        'prp = prp.Replace(" ", "")
                        indexArray(h) = prp
                        h += 1
                    End If
                End With
            Next
            Return indexArray
        End Function
    End Class
End Namespace
