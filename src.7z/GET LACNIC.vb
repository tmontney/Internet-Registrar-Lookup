﻿Imports System.Reflection
Namespace Internet_Registry.GET
    Public Class GET_LACNIC
        Public Property date_occurred As String = String.Empty
        Public Property address_scanned As String = String.Empty

        Public Property Handle As String
        Public Property Name As String
        Public Property Status As String
        Public Property Parent As String
        Public Property Net_Range As String
        Public Property Net_Version As String
        Public Property Country As String
        Public Property LAST_CHANGED As String

        Public Property adminHandle As String
        Public Property adminName As String
        Public Property Address As String
        Public Property adminCountry As String
        Public Property Postal_Code As String
        Public Property E_mail As String
        Public Property Telephone As String
        Public Property Registration As String
        Public Property adminLast_Changed As String

        Public Sub Retrieve(ByVal RiR_As_Collection As Collection, ByRef Get_Results_Obj As GET_LACNIC)
            'I'm not entirely pleased with this method. It seems overly complicated, and messy.
            'At the least, it will be hard to maintain. Hopefully, this is only temporary.
            Dim t As GET_LACNIC = Get_Results_Obj
            Dim subCollection As Collection = RiR_As_Collection
            Dim propInfo() As PropertyInfo = Me.GetType().GetProperties()
            Dim goToValue As Boolean = False
            Dim goToWhichValue As String = String.Empty
            Dim breakPassed As Boolean = False
            Dim j As Integer = 1
            For i As Integer = 0 To propInfo.Length - 1
                Dim curPropName As String = propInfo(i).Name
                curPropName = propInfo(i).Name
                If curPropName.Contains("_") And i <> 7 Then
                    curPropName = curPropName.Replace("_", " ")
                End If
                If breakPassed = True Then
                    curPropName = curPropName.Replace("admin", "")
                End If
                For Each element In subCollection
                    If breakPassed = True Then
                        If goToValue = False And element.Contains("Handle") And curPropName = "Handle" Then
                            goToValue = True
                            goToWhichValue = "Handle"
                        ElseIf goToValue = True And goToWhichValue = "Handle" Then
                            adminHandle = Remove_Tags(element)
                            goToValue = False
                            Exit For
                        ElseIf goToValue = False And element.Contains("Name") And curPropName = "Name" Then
                            goToValue = True
                            goToWhichValue = "Name"
                        ElseIf goToValue = True And goToWhichValue = "Name" Then
                            adminName = Remove_Tags(element)
                            goToValue = False
                            goToWhichValue = String.Empty
                            Exit For
                        ElseIf goToValue = False And element.Contains("Country") And curPropName = "Country" Then
                            goToValue = True
                            goToWhichValue = "Country"
                        ElseIf goToValue = True And goToWhichValue = "Country" Then
                            adminCountry = Remove_Tags(element)
                            goToValue = False
                            goToWhichValue = String.Empty
                            Exit For
                        ElseIf goToValue = False And element.Contains("Last Changed") And curPropName = "Last Changed" Then
                            goToValue = True
                            goToWhichValue = "Last Changed"
                        ElseIf goToValue = True And goToWhichValue = "Last Changed" Then
                            adminLast_Changed = Remove_Tags(element)
                            goToValue = False
                            goToWhichValue = String.Empty
                            Exit For
                        ElseIf element.Contains(curPropName) And goToValue = False Then
                            goToValue = True
                        ElseIf goToValue = True And element <> String.Empty Then
                            propInfo(i).SetValue(t, Remove_Tags(element), Nothing)
                            goToValue = False
                        End If
                    Else
                        If goToValue = False And element <> String.Empty And element.Contains(curPropName) Then
                            goToValue = True
                        ElseIf goToValue = True And element <> String.Empty Then
                            goToValue = False
                            element = Remove_Tags(element)
                            propInfo(i).SetValue(t, element, Nothing)
                            Exit For
                        End If
                    End If
                Next
                If curPropName = "LAST_CHANGED" Then
                    breakPassed = True
                End If
            Next
        End Sub

        Private Function Remove_Tags(ByVal value As String) As String
            Dim count As Integer = 0
            For Each character As Char In value
                If character = "<"c Then
                    count += 1
                End If
            Next
            For i As Integer = 0 To count - 1
                Dim startIndex As Integer = value.IndexOf("<"c)
                Dim endIndex As Integer = value.IndexOf(">"c) + 1
                value = value.Remove(startIndex, endIndex - startIndex)
            Next
            Return value
        End Function
    End Class
End Namespace
